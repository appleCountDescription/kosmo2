/*
$(function() {

	$('button.btn').click(function() {
		$('#iframe').css('display', 'inline-block');
	});

	$('td.info').click(function() {
		var num = $(this).text();
		alert(num + '칸을 선택하셨습니다.\n비밀번호를 설정해주십시오.');
		var o = open("pw.html", "창이름", "width=250, height=300,left=800,top=400");
	});

	$('.submit1').click(function(evt) {
		$('#worning').css('display', 'inline-block');
		opener.alert('비밀번호가 성공적으로 설정되었습니다.')
	});


	$('#exampleInputPassword1').click(function() {
		$('.a').click(function() {
			var currentValue = $("#password").val(); // 현재의 값이 input#password(입력한 수가 점으로 출력되는 줄)에 뜬다
			var newValue = currentValue + $(this).val().trim(); // 이어서 숫자 버튼을 누르면 currentValue에 입력한 값이 연속으로 더해진다
			$("#password").val(newValue); // 그 newValue값을 input#password에 뜨게 한다
		});
	});
})
*/







$(function() {
	$('button.btn').click(function() {
		$('#iframe').css('display', 'inline-block');
	});

	// 칸을 선택했을 때
	$('td.info').click(function() {
		var num = $(this).text();
		alert(num + '칸을 선택하셨습니다.\n비밀번호를 설정해주십시오.');
		var o = window.open("pw.html", "창이름", "width=350, height=500,left=800,top=400");
	});
	
	$('button#pwNum').click(function(evt) {
    	var currentValue = $("input#exampleInputPassword1").val();   // 현재의 값이 input#password(입력한 수가 점으로 출력되는 줄)에 뜬다 
    	var newValue = currentValue + $(this).val().trim();   // 이어서 숫자 버튼을 누르면 currentValue에 입력한 값이 연속으로 더해진다
    	$("input#exampleInputPassword1").val(newValue);   // 그 newValue값을 input#password에 뜨게 한다
	});

	$('#enter').click(function(evt) {
		$('#worning').css('display', 'inline-block');
		if ($('#exampleInputPassword1').val() != $('#exampleInputPassword2').val()) {
			evt.preventDefault();
			evt.stopPropagation();
			$('#worning').val("비밀번호가 일치하지 않습니다.");
		}
		if ($('#exampleInputPassword1').val() == $('#exampleInputPassword2').val()) {
			window.close();
		}
		opener.alert('비밀번호가 성공적으로 설정되었습니다.');
	});

	$('#exampleInputPassword1').click(function() {
		var key = window.open("key.html", "창이름2", "width=270, height=199,left=1060,top=400");
		$('.a').click(function() {
			var currentValue = $("#password").val(); // 현재의 값이 input#password(입력한 수가 점으로 출력되는 줄)에 뜬다
			var newValue = currentValue + $(this).val().trim(); // 이어서 숫자 버튼을 누르면 currentValue에 입력한 값이 연속으로 더해진다
			$("#password").val(newValue); // 그 newValue값을 input#password에 뜨게 한다
		});
	});

});
